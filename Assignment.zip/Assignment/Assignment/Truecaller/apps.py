from django.apps import AppConfig


class TruecallerConfig(AppConfig):
    name = 'Truecaller'
